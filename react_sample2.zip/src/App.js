import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {

//   React.useEffect(()=>{
//     alert("Hello and welcome to our first react from and life cycle event")
//   },[])

const [fname,setName] = React.useState('');
const [lname,setLname] = React.useState('');
const [email,setEmail] = React.useState('');
const [gender,setGender] = React.useState(''); 

// handleSubmit=()=>{

// }

// function handleSubmit(){

// }

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p><h1>I AM A REACT DEVELOPER</h1></p>
      </header>



      <div className="user-info-form">
      <form className="form1" onSubmit={e=>{e.preventDefault();
        console.log(fname);
        console.log(lname)
        console.log(email)
        console.log(gender)
        
        }}>
        <label className="label">
          First Name:
          <input type="text" value={fname} onChange={(event)=>setName(event.target.value)} className="input" name="fname" />
        </label>

        <label className="label">
          Last Name:
          <input type="text" value={lname} onChange={(event)=>setLname(event.target.value)} className="input" name="lname" />
        </label>

        <label  className="label">
          Eamil:
          <input type="text" value={email} onChange={(event)=>setEmail(event.target.value)} className="input" name="email" />
        </label>

        <label  className="label">
          Gender:
          <select name="gender" className="input" value={gender} onChange={(event)=>{setGender(event.target.value)}} >
            <option value=''>Select gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </label>


        <input className="button" type="submit" value="Submit" />
      </form>
      </div>



    </div>
  );
}

export default App;
